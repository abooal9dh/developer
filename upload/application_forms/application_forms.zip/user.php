<?php
  @require ('connect.php');
  @session_start();
?>
<?php echo '              <div class="d-flex d-grid gap-2 d-md-flex justify-content-center droid-arabic-kufi" >
                <form method = "POST" action="">
                
                </form>
            
<nav class="navbar navbar-expand-lg btn-outline-warning droid-arabic-kufi" dir="rtl">
  <div class="container-fluid btn-outline-warning">
    <a class="btn btn-outline-warning mx-1" href="#" style="font-size: 27px;">الرئيسية</a>
    <button class="navbar-toggler btn btn-outline-warning" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon btn-outline-warning" ></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
                <a class="btn btn-outline-warning mx-1" href="cp.php" style="font-size: 27px;" >لوحة التحكم</a>
                <a class="btn btn-outline-warning mx-1" href="cp.php" style="font-size: 27px;">لماذا تختارنا</a>
                <a class="btn btn-outline-warning mx-1" href="cp.php" style="font-size: 27px;">المسؤلية الإجتماعية</a>
                <a class="btn btn-outline-warning mx-1" href="app.php" style="font-size: 27px;">خدمات المكتب</a>
                <button class="btn btn-outline-warning mx-1" type="submit" name="exit" style="font-size: 27px;">خروج</button>
    </div>
  </div>
</nav>
<header>
                </div>
<br>';
?>